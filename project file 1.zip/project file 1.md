

```python
from sklearn.datasets import load_boston
import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
%matplotlib inline
import warnings
warnings.filterwarnings('ignore')
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import RFE
from sklearn.linear_model import RidgeCV, LassoCV, Ridge, Lasso
```

# Descriptive statistics

percentage of gender:


```python
data=pd.read_csv('coorg.sav.csv')
data.head()
data.drop('Name',axis=1).head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AGE</th>
      <th>Gender</th>
      <th>Domicile</th>
      <th>Qualification</th>
      <th>Religion</th>
      <th>Occupation</th>
      <th>Marital status</th>
      <th>Socio economic status</th>
      <th>Duration of illness</th>
      <th>BFNE Score</th>
      <th>PANSS score</th>
      <th>P score</th>
      <th>N score</th>
      <th>G score</th>
      <th>C score</th>
      <th>CGI Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>40</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Muslim</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>15.0</td>
      <td>27</td>
      <td>45</td>
      <td>7</td>
      <td>11</td>
      <td>27</td>
      <td>-4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>32</td>
      <td>F</td>
      <td>Urban</td>
      <td>Graduated</td>
      <td>Christian</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Middle</td>
      <td>4.0</td>
      <td>30</td>
      <td>71</td>
      <td>27</td>
      <td>14</td>
      <td>30</td>
      <td>13</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>35</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Middle</td>
      <td>3.0</td>
      <td>20</td>
      <td>71</td>
      <td>23</td>
      <td>14</td>
      <td>34</td>
      <td>9</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>26</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Farmer</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>12</td>
      <td>48</td>
      <td>9</td>
      <td>15</td>
      <td>24</td>
      <td>-6</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>31</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>2.0</td>
      <td>12</td>
      <td>59</td>
      <td>17</td>
      <td>11</td>
      <td>31</td>
      <td>6</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
(data['Gender']).value_counts()
```




    F    26
    M    24
    Name: Gender, dtype: int64




```python
(data['Socio economic status']).value_counts()
```




    Low       43
    Middle     7
    Name: Socio economic status, dtype: int64




```python
(data['Domicile']).value_counts()
```




    Rural    36
    Urban    14
    Name: Domicile, dtype: int64




```python
(data['Marital status']).value_counts()
```




    Married      30
    Unmarried    16
    Widow         2
    Separated     1
    Divorced      1
    Name: Marital status, dtype: int64




```python
def year(x):
    if x<1:
        return "less than 1 year"
    elif 1<=x<5:
        return "01 to 5"
    elif 5<=x<10:
        return "05 to 10"
    elif 10<=x<15:
        return "10 to 15"
    elif 15<=x<20:
        return "15 to 20"
    elif 20<=x<25:
        return "20 to 25"
    else:
        return "25 and above"

data['duration of illness in years']=data['Duration of illness'].apply(year)
```


```python
(data['duration of illness in years']).value_counts()
```




    01 to 5             20
    05 to 10             7
    10 to 15             7
    25 and above         6
    15 to 20             6
    less than 1 year     3
    20 to 25             1
    Name: duration of illness in years, dtype: int64




```python
data[data['BFNE Score']>=25]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>AGE</th>
      <th>Gender</th>
      <th>Domicile</th>
      <th>Qualification</th>
      <th>Religion</th>
      <th>Occupation</th>
      <th>Marital status</th>
      <th>Socio economic status</th>
      <th>Duration of illness</th>
      <th>BFNE Score</th>
      <th>PANSS score</th>
      <th>P score</th>
      <th>N score</th>
      <th>G score</th>
      <th>C score</th>
      <th>CGI Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Asma Begum</td>
      <td>40</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Muslim</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>15.0</td>
      <td>27</td>
      <td>45</td>
      <td>7</td>
      <td>11</td>
      <td>27</td>
      <td>-4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Prasanna kumari</td>
      <td>32</td>
      <td>F</td>
      <td>Urban</td>
      <td>Graduated</td>
      <td>Christian</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Middle</td>
      <td>4.0</td>
      <td>30</td>
      <td>71</td>
      <td>27</td>
      <td>14</td>
      <td>30</td>
      <td>13</td>
      <td>5</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Vasantha Shiva</td>
      <td>48</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Vendor</td>
      <td>Married</td>
      <td>Middle</td>
      <td>0.3</td>
      <td>30</td>
      <td>124</td>
      <td>25</td>
      <td>35</td>
      <td>64</td>
      <td>-10</td>
      <td>6</td>
    </tr>
    <tr>
      <th>18</th>
      <td>V.Vamsi</td>
      <td>31</td>
      <td>M</td>
      <td>Rural</td>
      <td>Graduated</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Middle</td>
      <td>10.0</td>
      <td>32</td>
      <td>102</td>
      <td>17</td>
      <td>32</td>
      <td>53</td>
      <td>-15</td>
      <td>6</td>
    </tr>
    <tr>
      <th>19</th>
      <td>T. Veeraiah</td>
      <td>43</td>
      <td>M</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Farmer</td>
      <td>Married</td>
      <td>Low</td>
      <td>0.6</td>
      <td>28</td>
      <td>126</td>
      <td>33</td>
      <td>23</td>
      <td>70</td>
      <td>10</td>
      <td>6</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Mani Maloth</td>
      <td>41</td>
      <td>F</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Farmer</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>35</td>
      <td>61</td>
      <td>20</td>
      <td>10</td>
      <td>31</td>
      <td>10</td>
      <td>4</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Swamy Gargula</td>
      <td>26</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>5.0</td>
      <td>29</td>
      <td>71</td>
      <td>21</td>
      <td>14</td>
      <td>36</td>
      <td>7</td>
      <td>5</td>
    </tr>
    <tr>
      <th>29</th>
      <td>nazma Begum</td>
      <td>40</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Muslim</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>15.0</td>
      <td>27</td>
      <td>42</td>
      <td>7</td>
      <td>11</td>
      <td>24</td>
      <td>-4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Mumtaz Begum</td>
      <td>57</td>
      <td>F</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Muslim</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>45</td>
      <td>74</td>
      <td>18</td>
      <td>21</td>
      <td>35</td>
      <td>-3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>31</th>
      <td>K.Gopi</td>
      <td>20</td>
      <td>M</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>3.0</td>
      <td>25</td>
      <td>70</td>
      <td>10</td>
      <td>30</td>
      <td>30</td>
      <td>-20</td>
      <td>4</td>
    </tr>
    <tr>
      <th>47</th>
      <td>ramesh</td>
      <td>48</td>
      <td>M</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Vendor</td>
      <td>Married</td>
      <td>Middle</td>
      <td>0.3</td>
      <td>30</td>
      <td>124</td>
      <td>25</td>
      <td>35</td>
      <td>64</td>
      <td>-10</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
data[data['BFNE Score']<25]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>AGE</th>
      <th>Gender</th>
      <th>Domicile</th>
      <th>Qualification</th>
      <th>Religion</th>
      <th>Occupation</th>
      <th>Marital status</th>
      <th>Socio economic status</th>
      <th>Duration of illness</th>
      <th>BFNE Score</th>
      <th>PANSS score</th>
      <th>P score</th>
      <th>N score</th>
      <th>G score</th>
      <th>C score</th>
      <th>CGI Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>Rajeswari</td>
      <td>35</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Middle</td>
      <td>3.0</td>
      <td>20</td>
      <td>71</td>
      <td>23</td>
      <td>14</td>
      <td>34</td>
      <td>9</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Y. Srikanth</td>
      <td>26</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Farmer</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>12</td>
      <td>48</td>
      <td>9</td>
      <td>15</td>
      <td>24</td>
      <td>-6</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Saketh</td>
      <td>31</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>2.0</td>
      <td>12</td>
      <td>59</td>
      <td>17</td>
      <td>11</td>
      <td>31</td>
      <td>6</td>
      <td>4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>M.Devender</td>
      <td>27</td>
      <td>M</td>
      <td>Rural</td>
      <td>Graduated</td>
      <td>Hindu</td>
      <td>unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>7.0</td>
      <td>15</td>
      <td>83</td>
      <td>20</td>
      <td>22</td>
      <td>41</td>
      <td>-2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Bala kishan</td>
      <td>45</td>
      <td>M</td>
      <td>Rural</td>
      <td>Graduated</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Divorced</td>
      <td>Middle</td>
      <td>20.0</td>
      <td>17</td>
      <td>75</td>
      <td>24</td>
      <td>11</td>
      <td>40</td>
      <td>13</td>
      <td>5</td>
    </tr>
    <tr>
      <th>7</th>
      <td>S.Srinivas</td>
      <td>27</td>
      <td>M</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Christian</td>
      <td>Unemployed</td>
      <td>Separated</td>
      <td>Low</td>
      <td>5.0</td>
      <td>15</td>
      <td>95</td>
      <td>18</td>
      <td>33</td>
      <td>44</td>
      <td>-15</td>
      <td>6</td>
    </tr>
    <tr>
      <th>8</th>
      <td>P.Yedukondalu</td>
      <td>30</td>
      <td>M</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>15.0</td>
      <td>19</td>
      <td>94</td>
      <td>15</td>
      <td>39</td>
      <td>40</td>
      <td>-24</td>
      <td>6</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ramulu</td>
      <td>60</td>
      <td>M</td>
      <td>Urban</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>30.0</td>
      <td>12</td>
      <td>54</td>
      <td>17</td>
      <td>13</td>
      <td>24</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>10</th>
      <td>M.Bhavani</td>
      <td>32</td>
      <td>F</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Labourer</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>12.0</td>
      <td>20</td>
      <td>58</td>
      <td>18</td>
      <td>12</td>
      <td>28</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Lakshmi Jaadi</td>
      <td>38</td>
      <td>F</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>12</td>
      <td>57</td>
      <td>16</td>
      <td>12</td>
      <td>29</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Gangamma Panja</td>
      <td>46</td>
      <td>F</td>
      <td>Urban</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>15.0</td>
      <td>12</td>
      <td>78</td>
      <td>32</td>
      <td>15</td>
      <td>31</td>
      <td>17</td>
      <td>4</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Ambika</td>
      <td>25</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Tailor</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>1.0</td>
      <td>24</td>
      <td>44</td>
      <td>11</td>
      <td>7</td>
      <td>26</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>15</th>
      <td>P.yadamma</td>
      <td>45</td>
      <td>F</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Widow</td>
      <td>Low</td>
      <td>25.0</td>
      <td>19</td>
      <td>100</td>
      <td>18</td>
      <td>33</td>
      <td>49</td>
      <td>-15</td>
      <td>5</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Sk Shakila</td>
      <td>40</td>
      <td>F</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Muslim</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>10.0</td>
      <td>14</td>
      <td>104</td>
      <td>22</td>
      <td>29</td>
      <td>53</td>
      <td>-7</td>
      <td>7</td>
    </tr>
    <tr>
      <th>17</th>
      <td>B.Savitha</td>
      <td>27</td>
      <td>F</td>
      <td>Rural</td>
      <td>Primary</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>3.0</td>
      <td>15</td>
      <td>54</td>
      <td>17</td>
      <td>9</td>
      <td>28</td>
      <td>8</td>
      <td>4</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Satya Narayana</td>
      <td>40</td>
      <td>M</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Labourer</td>
      <td>Married</td>
      <td>Low</td>
      <td>2.0</td>
      <td>12</td>
      <td>91</td>
      <td>26</td>
      <td>20</td>
      <td>45</td>
      <td>6</td>
      <td>4</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Madhavi</td>
      <td>43</td>
      <td>F</td>
      <td>Urban</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>2.0</td>
      <td>16</td>
      <td>65</td>
      <td>20</td>
      <td>10</td>
      <td>35</td>
      <td>10</td>
      <td>4</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Renuka Lenkala</td>
      <td>33</td>
      <td>F</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>6.0</td>
      <td>12</td>
      <td>54</td>
      <td>14</td>
      <td>12</td>
      <td>28</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Chennaiah</td>
      <td>33</td>
      <td>M</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Labourer</td>
      <td>Married</td>
      <td>Low</td>
      <td>10.0</td>
      <td>12</td>
      <td>83</td>
      <td>28</td>
      <td>20</td>
      <td>35</td>
      <td>8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Duryodhanudu K</td>
      <td>52</td>
      <td>M</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Labourer</td>
      <td>Married</td>
      <td>Low</td>
      <td>30.0</td>
      <td>12</td>
      <td>66</td>
      <td>16</td>
      <td>19</td>
      <td>31</td>
      <td>-3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>27</th>
      <td>B.laxman</td>
      <td>34</td>
      <td>M</td>
      <td>Rural</td>
      <td>Graduated</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>4.0</td>
      <td>12</td>
      <td>85</td>
      <td>20</td>
      <td>30</td>
      <td>35</td>
      <td>-10</td>
      <td>5</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Ravinder Edla</td>
      <td>32</td>
      <td>M</td>
      <td>Rural</td>
      <td>Graduated</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>5.0</td>
      <td>14</td>
      <td>60</td>
      <td>18</td>
      <td>13</td>
      <td>29</td>
      <td>5</td>
      <td>4</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Sudhakar</td>
      <td>35</td>
      <td>M</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>6.0</td>
      <td>20</td>
      <td>62</td>
      <td>7</td>
      <td>23</td>
      <td>32</td>
      <td>-16</td>
      <td>4</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Shradha</td>
      <td>28</td>
      <td>F</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>5.0</td>
      <td>17</td>
      <td>58</td>
      <td>8</td>
      <td>24</td>
      <td>26</td>
      <td>-16</td>
      <td>3</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Anantha Kumari</td>
      <td>45</td>
      <td>F</td>
      <td>Rural</td>
      <td>Graduated</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Middle</td>
      <td>2.5</td>
      <td>23</td>
      <td>61</td>
      <td>17</td>
      <td>17</td>
      <td>27</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Manjula</td>
      <td>45</td>
      <td>F</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>12.0</td>
      <td>19</td>
      <td>44</td>
      <td>12</td>
      <td>12</td>
      <td>20</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>36</th>
      <td>C. Nagasheshudu</td>
      <td>35</td>
      <td>M</td>
      <td>Rural</td>
      <td>Primary</td>
      <td>Hindu</td>
      <td>Labourer</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>2.0</td>
      <td>19</td>
      <td>48</td>
      <td>14</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>3</td>
    </tr>
    <tr>
      <th>37</th>
      <td>Neeraja</td>
      <td>20</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>3.0</td>
      <td>15</td>
      <td>59</td>
      <td>21</td>
      <td>9</td>
      <td>29</td>
      <td>12</td>
      <td>4</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Navya</td>
      <td>35</td>
      <td>F</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Farmer</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>18</td>
      <td>49</td>
      <td>18</td>
      <td>9</td>
      <td>23</td>
      <td>9</td>
      <td>4</td>
    </tr>
    <tr>
      <th>39</th>
      <td>Komaraiah</td>
      <td>55</td>
      <td>M</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Labourer</td>
      <td>Married</td>
      <td>Low</td>
      <td>30.0</td>
      <td>17</td>
      <td>62</td>
      <td>17</td>
      <td>19</td>
      <td>26</td>
      <td>-2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Sujith</td>
      <td>20</td>
      <td>M</td>
      <td>Rural</td>
      <td>Graduated</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>2.0</td>
      <td>13</td>
      <td>51</td>
      <td>18</td>
      <td>9</td>
      <td>24</td>
      <td>9</td>
      <td>4</td>
    </tr>
    <tr>
      <th>41</th>
      <td>chinnaiah</td>
      <td>30</td>
      <td>M</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>15.0</td>
      <td>19</td>
      <td>94</td>
      <td>15</td>
      <td>39</td>
      <td>40</td>
      <td>-24</td>
      <td>6</td>
    </tr>
    <tr>
      <th>42</th>
      <td>srinu</td>
      <td>60</td>
      <td>M</td>
      <td>Urban</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>30.0</td>
      <td>12</td>
      <td>54</td>
      <td>17</td>
      <td>13</td>
      <td>24</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>43</th>
      <td>shanta</td>
      <td>32</td>
      <td>F</td>
      <td>Rural</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Labourer</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>12.0</td>
      <td>20</td>
      <td>58</td>
      <td>18</td>
      <td>12</td>
      <td>28</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>44</th>
      <td>venkamma</td>
      <td>38</td>
      <td>F</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>12</td>
      <td>57</td>
      <td>16</td>
      <td>12</td>
      <td>29</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>45</th>
      <td>divya</td>
      <td>46</td>
      <td>F</td>
      <td>Urban</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>15.0</td>
      <td>12</td>
      <td>78</td>
      <td>32</td>
      <td>15</td>
      <td>31</td>
      <td>17</td>
      <td>4</td>
    </tr>
    <tr>
      <th>46</th>
      <td>laxmi</td>
      <td>25</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>Tailor</td>
      <td>Unmarried</td>
      <td>Low</td>
      <td>1.0</td>
      <td>24</td>
      <td>44</td>
      <td>11</td>
      <td>7</td>
      <td>26</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>48</th>
      <td>jangamma</td>
      <td>45</td>
      <td>F</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Widow</td>
      <td>Low</td>
      <td>25.0</td>
      <td>19</td>
      <td>100</td>
      <td>18</td>
      <td>33</td>
      <td>49</td>
      <td>-15</td>
      <td>5</td>
    </tr>
    <tr>
      <th>49</th>
      <td>irfan</td>
      <td>40</td>
      <td>M</td>
      <td>Rural</td>
      <td>Illiterate</td>
      <td>Muslim</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>10.0</td>
      <td>14</td>
      <td>104</td>
      <td>22</td>
      <td>29</td>
      <td>53</td>
      <td>-7</td>
      <td>7</td>
    </tr>
  </tbody>
</table>
</div>




```python
(data['Religion']).value_counts()
```




    Hindu        43
    Muslim        5
    Christian     2
    Name: Religion, dtype: int64




```python
(data['Qualification']).value_counts()
```




    Secondary     19
    Illiterate    17
    Graduated      8
    Inter          4
    Primary        2
    Name: Qualification, dtype: int64




```python
(data['BFNE Score']>=25).value_counts()
```




    False    39
    True     11
    Name: BFNE Score, dtype: int64




```python
def bfne(x):
    if 0<=x<25:
        return "less than 25"
    else:
        return "more than 25"
    
data['BFNE Score_cat']=data['BFNE Score'].apply(bfne)
data.head()        
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>AGE</th>
      <th>Gender</th>
      <th>Domicile</th>
      <th>Qualification</th>
      <th>Religion</th>
      <th>Occupation</th>
      <th>Marital status</th>
      <th>Socio economic status</th>
      <th>Duration of illness</th>
      <th>BFNE Score</th>
      <th>PANSS score</th>
      <th>P score</th>
      <th>N score</th>
      <th>G score</th>
      <th>C score</th>
      <th>CGI Score</th>
      <th>BFNE Score_cat</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Asma Begum</td>
      <td>40</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Muslim</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>15.0</td>
      <td>27</td>
      <td>45</td>
      <td>7</td>
      <td>11</td>
      <td>27</td>
      <td>-4</td>
      <td>3</td>
      <td>more than 25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Prasanna kumari</td>
      <td>32</td>
      <td>F</td>
      <td>Urban</td>
      <td>Graduated</td>
      <td>Christian</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Middle</td>
      <td>4.0</td>
      <td>30</td>
      <td>71</td>
      <td>27</td>
      <td>14</td>
      <td>30</td>
      <td>13</td>
      <td>5</td>
      <td>more than 25</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rajeswari</td>
      <td>35</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Middle</td>
      <td>3.0</td>
      <td>20</td>
      <td>71</td>
      <td>23</td>
      <td>14</td>
      <td>34</td>
      <td>9</td>
      <td>5</td>
      <td>less than 25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Y. Srikanth</td>
      <td>26</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Farmer</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>12</td>
      <td>48</td>
      <td>9</td>
      <td>15</td>
      <td>24</td>
      <td>-6</td>
      <td>4</td>
      <td>less than 25</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Saketh</td>
      <td>31</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>2.0</td>
      <td>12</td>
      <td>59</td>
      <td>17</td>
      <td>11</td>
      <td>31</td>
      <td>6</td>
      <td>4</td>
      <td>less than 25</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.crosstab(data['Gender'],data['BFNE Score_cat'],normalize=0).plot.bar(stacked=True,legend=True)
plt.show()

```


![png](output_16_0.png)



```python
pd.crosstab(data['Marital status'],data['BFNE Score_cat'],normalize=0).plot.bar(stacked=True,legend=True)
plt.show()
```


![png](output_17_0.png)



```python
pd.crosstab(data['Socio economic status'],data['BFNE Score_cat'],normalize=0).plot.bar(stacked=True,legend=True)
plt.show()
```


![png](output_18_0.png)



```python
pd.crosstab(data['Qualification'],data['BFNE Score_cat'],normalize=0).plot.bar(stacked=True,legend=True)
plt.show()
```


![png](output_19_0.png)



```python
pd.crosstab(data['Domicile'],data['BFNE Score_cat'],normalize=0).plot.bar(stacked=True,legend=True)
plt.show()
```


![png](output_20_0.png)



```python
def age(x):
    if 0<=x<25:
        return "less than 25"
    elif 25<=x<45:
        return "25 - 45"
    else:
        return "more than 45"
data['Age_cat']=data['AGE'].apply(age)
data.head()        
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>AGE</th>
      <th>Gender</th>
      <th>Domicile</th>
      <th>Qualification</th>
      <th>Religion</th>
      <th>Occupation</th>
      <th>Marital status</th>
      <th>Socio economic status</th>
      <th>Duration of illness</th>
      <th>BFNE Score</th>
      <th>PANSS score</th>
      <th>P score</th>
      <th>N score</th>
      <th>G score</th>
      <th>C score</th>
      <th>CGI Score</th>
      <th>BFNE Score_cat</th>
      <th>Age_cat</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Asma Begum</td>
      <td>40</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Muslim</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Low</td>
      <td>15.0</td>
      <td>27</td>
      <td>45</td>
      <td>7</td>
      <td>11</td>
      <td>27</td>
      <td>-4</td>
      <td>3</td>
      <td>more than 25</td>
      <td>25 - 45</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Prasanna kumari</td>
      <td>32</td>
      <td>F</td>
      <td>Urban</td>
      <td>Graduated</td>
      <td>Christian</td>
      <td>Unemployed</td>
      <td>Unmarried</td>
      <td>Middle</td>
      <td>4.0</td>
      <td>30</td>
      <td>71</td>
      <td>27</td>
      <td>14</td>
      <td>30</td>
      <td>13</td>
      <td>5</td>
      <td>more than 25</td>
      <td>25 - 45</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rajeswari</td>
      <td>35</td>
      <td>F</td>
      <td>Urban</td>
      <td>Secondary</td>
      <td>Hindu</td>
      <td>House wife</td>
      <td>Married</td>
      <td>Middle</td>
      <td>3.0</td>
      <td>20</td>
      <td>71</td>
      <td>23</td>
      <td>14</td>
      <td>34</td>
      <td>9</td>
      <td>5</td>
      <td>less than 25</td>
      <td>25 - 45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Y. Srikanth</td>
      <td>26</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Farmer</td>
      <td>Married</td>
      <td>Low</td>
      <td>1.0</td>
      <td>12</td>
      <td>48</td>
      <td>9</td>
      <td>15</td>
      <td>24</td>
      <td>-6</td>
      <td>4</td>
      <td>less than 25</td>
      <td>25 - 45</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Saketh</td>
      <td>31</td>
      <td>M</td>
      <td>Rural</td>
      <td>Inter</td>
      <td>Hindu</td>
      <td>Unemployed</td>
      <td>Married</td>
      <td>Low</td>
      <td>2.0</td>
      <td>12</td>
      <td>59</td>
      <td>17</td>
      <td>11</td>
      <td>31</td>
      <td>6</td>
      <td>4</td>
      <td>less than 25</td>
      <td>25 - 45</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.crosstab(data['Age_cat'],data['BFNE Score_cat'],normalize=0).plot.bar(stacked=True,legend=True)
plt.show()
```


![png](output_22_0.png)



```python
data1=data.drop(['Name','AGE','Gender','Domicile','Qualification','Religion','Occupation','Marital status',
           'Socio economic status','Duration of illness','Age_cat','C score','BFNE Score_cat'],axis=1)
data1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BFNE Score</th>
      <th>PANSS score</th>
      <th>P score</th>
      <th>N score</th>
      <th>G score</th>
      <th>CGI Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>27</td>
      <td>45</td>
      <td>7</td>
      <td>11</td>
      <td>27</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>30</td>
      <td>71</td>
      <td>27</td>
      <td>14</td>
      <td>30</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>20</td>
      <td>71</td>
      <td>23</td>
      <td>14</td>
      <td>34</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12</td>
      <td>48</td>
      <td>9</td>
      <td>15</td>
      <td>24</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12</td>
      <td>59</td>
      <td>17</td>
      <td>11</td>
      <td>31</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
x=data1.drop('BFNE Score',axis=1)
y=data1['BFNE Score']
x_constant=sm.add_constant(x)
model=sm.OLS(y,x_constant).fit()
predictions=model.predict(x_constant)
model.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>BFNE Score</td>    <th>  R-squared:         </th> <td>   0.152</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.056</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   1.582</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 13 Oct 2019</td> <th>  Prob (F-statistic):</th>  <td> 0.185</td> 
</tr>
<tr>
  <th>Time:</th>                 <td>22:40:11</td>     <th>  Log-Likelihood:    </th> <td> -166.64</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>    50</td>      <th>  AIC:               </th> <td>   345.3</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    44</td>      <th>  BIC:               </th> <td>   356.8</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     5</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>       <td>   19.0420</td> <td>    5.028</td> <td>    3.787</td> <td> 0.000</td> <td>    8.910</td> <td>   29.174</td>
</tr>
<tr>
  <th>PANSS score</th> <td>   -2.0095</td> <td>    7.435</td> <td>   -0.270</td> <td> 0.788</td> <td>  -16.994</td> <td>   12.975</td>
</tr>
<tr>
  <th>P score</th>     <td>    1.6699</td> <td>    7.431</td> <td>    0.225</td> <td> 0.823</td> <td>  -13.306</td> <td>   16.645</td>
</tr>
<tr>
  <th>N score</th>     <td>    1.8777</td> <td>    7.450</td> <td>    0.252</td> <td> 0.802</td> <td>  -13.136</td> <td>   16.891</td>
</tr>
<tr>
  <th>G score</th>     <td>    2.4551</td> <td>    7.456</td> <td>    0.329</td> <td> 0.744</td> <td>  -12.573</td> <td>   17.483</td>
</tr>
<tr>
  <th>CGI Score</th>   <td>   -1.4999</td> <td>    1.849</td> <td>   -0.811</td> <td> 0.421</td> <td>   -5.225</td> <td>    2.226</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>21.994</td> <th>  Durbin-Watson:     </th> <td>   1.791</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td>  32.764</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.468</td> <th>  Prob(JB):          </th> <td>7.68e-08</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.665</td> <th>  Cond. No.          </th> <td>1.28e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 1.28e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
X_var = sm.add_constant(x)
model = sm.OLS(y,X_var).fit()
model.pvalues
```




    const          0.000458
    PANSS score    0.788216
    P score        0.823233
    N score        0.802173
    G score        0.743528
    CGI Score      0.421499
    dtype: float64




```python
plt.figure(figsize=(10,5))
sns.barplot(x='duration of illness in years', y='BFNE Score', data=data,palette='muted');
```


![png](output_26_0.png)



```python
plt.figure(figsize=(10,5))
sns.barplot(x='Marital status', y='BFNE Score', data=data,palette='muted');
```


![png](output_27_0.png)



```python
X = data1.drop('BFNE Score', axis=1)
y= data1['BFNE Score']
from sklearn.linear_model import LinearRegression

lin_reg = LinearRegression()
lin_reg.fit(X, y)
print(f'Coefficients: {lin_reg.coef_}')
print(f'Intercept: {lin_reg.intercept_}')
print(f'R^2 score: {lin_reg.score(X, y)}')
```

    Coefficients: [-2.00949809  1.66985769  1.8776931   2.45505927 -1.49991478]
    Intercept: 19.04202581720073
    R^2 score: 0.15241887646556485
    


```python
from sklearn.model_selection import train_test_split
X_train, X_test , y_train, y_test = train_test_split(X,y, test_size = 0.30, random_state = 1)
print(X_train.shape)
print(X_test.shape)
```

    (35, 5)
    (15, 5)
    


```python
import warnings 
warnings.filterwarnings('ignore')
import statsmodels.api as sm

X_constant = sm.add_constant(X)
lin_reg = sm.OLS(y,X_constant).fit()
lin_reg.summary()


```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>BFNE Score</td>    <th>  R-squared:         </th> <td>   0.152</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.056</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   1.582</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 13 Oct 2019</td> <th>  Prob (F-statistic):</th>  <td> 0.185</td> 
</tr>
<tr>
  <th>Time:</th>                 <td>22:53:19</td>     <th>  Log-Likelihood:    </th> <td> -166.64</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>    50</td>      <th>  AIC:               </th> <td>   345.3</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    44</td>      <th>  BIC:               </th> <td>   356.8</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     5</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>       <td>   19.0420</td> <td>    5.028</td> <td>    3.787</td> <td> 0.000</td> <td>    8.910</td> <td>   29.174</td>
</tr>
<tr>
  <th>PANSS score</th> <td>   -2.0095</td> <td>    7.435</td> <td>   -0.270</td> <td> 0.788</td> <td>  -16.994</td> <td>   12.975</td>
</tr>
<tr>
  <th>P score</th>     <td>    1.6699</td> <td>    7.431</td> <td>    0.225</td> <td> 0.823</td> <td>  -13.306</td> <td>   16.645</td>
</tr>
<tr>
  <th>N score</th>     <td>    1.8777</td> <td>    7.450</td> <td>    0.252</td> <td> 0.802</td> <td>  -13.136</td> <td>   16.891</td>
</tr>
<tr>
  <th>G score</th>     <td>    2.4551</td> <td>    7.456</td> <td>    0.329</td> <td> 0.744</td> <td>  -12.573</td> <td>   17.483</td>
</tr>
<tr>
  <th>CGI Score</th>   <td>   -1.4999</td> <td>    1.849</td> <td>   -0.811</td> <td> 0.421</td> <td>   -5.225</td> <td>    2.226</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>21.994</td> <th>  Durbin-Watson:     </th> <td>   1.791</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td>  32.764</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.468</td> <th>  Prob(JB):          </th> <td>7.68e-08</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.665</td> <th>  Cond. No.          </th> <td>1.28e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 1.28e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
import warnings 
warnings.filterwarnings('ignore')
import statsmodels.api as sm
import statsmodels.tsa.api as smt

acf = smt.graphics.plot_acf(lin_reg.resid, lags=40 , alpha=0.05)
acf.show()
```


![png](output_31_0.png)



```python

```


```python

```
